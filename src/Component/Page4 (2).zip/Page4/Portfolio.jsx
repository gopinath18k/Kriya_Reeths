import React from 'react'
import HorizontalSlider from './Carouselee/examplee'
import Footerel from '../Page2/Lfooter/Lfooter'
import "../Page4/Portfolio.css"
import bg1 from '../../images/bg-text1.svg'

const Portfolioo = () => {
  return (
    <div className='container-fluid navmain'>
         <div className='ab-section1'>
          <h1 className='head2'>Portfolio</h1>

          <p className='head3-p'>Our portfolio showcases our creative and strategic capabilities through a diverse range of projects. Discover our work in graphic design, web development, digital marketing, event management, and photography/videography. Each project reflects our commitment to innovation, creativity, and client satisfaction </p>
        </div>

       
        <div className="ab-section4">
          <div className='bg1-cont'>
            <img className='bg-txt11' src={bg1} alt="" />
          </div>
          
          <div className='creativ-head'>
            <h1 >Creative Minds</h1>
            <p>Our team combines diverse talents to innovate and deliver compelling digital marketing strategies that captivate and inspire. 
            </p>
          </div>
          <div className='tslider'>
          <HorizontalSlider/>
          </div>
        </div>
    </div>
  )
}

export default Portfolioo