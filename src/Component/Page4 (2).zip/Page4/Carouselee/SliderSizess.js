import React from "react";
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import { styled } from '@mui/material/styles';
import './SliderSizesse.css';

const stages = [0, 25, 50, 75, 100];
const labels = [
  'Graphic Design',
  'Web Development',
  'Pay-Per-Click Advertising (PPC)',
  'Event Management',
  'Photo/Video'
];

const gradients = [
  'linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(255,255,255,1) 25%, rgba(43,43,43,1) 100%)', 
  'linear-gradient(90deg, rgba(43,43,43,1) 0%, rgba(255,255,255,1) 25%, rgba(43,43,43,1) 100%)',
  'linear-gradient(90deg, rgba(43,43,43,1) 0%, rgba(255,255,255,1) 50%, rgba(43,43,43,1) 100%)',
  'linear-gradient(90deg, rgba(43,43,43,1) 0%, rgba(255,255,255,1) 75%, rgba(43,43,43,1) 100%)',
  'linear-gradient(90deg, rgba(43,43,43,1) 0%, rgba(255,255,255,1) 75%, rgba(255,255,255,1) 100%)'
];

const GradientSliders = styled(Slider)(({ theme, background }) => ({
  color: 'transparent',
  height: '6px',
  width: '100%', 
  padding: '0 10px',
  background: background, 
  '& .MuiSlider-thumb': {
    backgroundColor: '#2b2b2b',
    border: '3px solid white',
    width: 20,
    height: 20,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  '& .MuiSlider-mark': {
    display: 'none', 
  },

  '@media (max-width: 1500px)': {
    height: '8px',
    padding:'0',
    '& .MuiSlider-thumb': {
      width: 25,
      height: 25,
    },
  },

  '@media (max-width: 1300px)': {
    height: '6px',
    padding:'0',
    '& .MuiSlider-thumb': {
      width: 19,
      height: 19,
    },
  },
  // Media Queries
  '@media (max-width: 830px)': {
    height: '6px',
    padding:'0',
    '& .MuiSlider-thumb': {
      width: 14,
      height: 14,
    },
  },
  '@media (max-width: 480px)': {
    height: '6px',
    padding:'0',
    '& .MuiSlider-thumb': {
      width: 14,
      height: 14,
    },
  },
}));

export default function SliderLine({ currentValue, onSliderChange }) {
  const handleScroll = (event) => {
    event.preventDefault();
    const deltaX = event.deltaX; 
    const currentIndex = stages.indexOf(currentValue);
    let newIndex = currentIndex;

    if (deltaX > 0) {
      newIndex = (currentIndex + 1) % stages.length;
    } else {
      newIndex = (currentIndex - 1 + stages.length) % stages.length;
    }

    onSliderChange(stages[newIndex]);
  };

  const handleChange = (event, newValue) => {
    onSliderChange(newValue);
  };

  const getLabelPosition = (value) => {
    const percentage = (value - stages[0]) / (stages[stages.length - 1] - stages[0]);
    return `${percentage * 100}%`;
  };

  const currentGradient = gradients[stages.indexOf(currentValue)];

  return (
    // <div className='scroll-container' onWheel={handleScroll} style={{ position: 'relative' }}>
    <div className='scroll-container'  style={{ position: 'relative' }}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: 50,  
          width: '100%',
          position: 'relative',
        }}
      >
        <GradientSliders
          orientation="horizontal"
          value={currentValue}
          aria-label="Default"
          step={null}
          marks={stages.map((stage, index) => ({ value: stage}))}
          // marks={stages.map((stage, index) => ({ value: stage, label: labels[index] }))}
          onChange={handleChange}
          valueLabelDisplay="off" 
          background={currentGradient}
        />
        <div className="scroll-label"
          style={{
            left: `calc(${getLabelPosition(currentValue)} - 30px)`,
          }}
        >
          {labels[stages.indexOf(currentValue)]}
        </div>
      </Box>
    </div>
  );
}
