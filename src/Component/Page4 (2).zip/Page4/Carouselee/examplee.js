import React, { Component } from "react";
import { config } from "react-spring";
import "./examplee.css";
import '../Carouselee/portfolio-sub/Ev.css'
import '../Carouselee/portfolio-sub/Photo.css'
import '../Carouselee/portfolio-sub/Web.css'
import '../Carouselee/portfolio-sub/Pay-per.css'
import HorizontalCarousel from "./VerticalCarousele";
import SliderLine from "./SliderSizess";
import './Krgallery.css'
import r1 from '../../../images/g1.png';
import r2 from '../../../images/g2.png';
import r3 from '../../../images/g3.png';
import r4 from '../../../images/g4.png';
import r5 from '../../../images/g5.png';
import r6 from '../../../images/g6.png';
import r7 from '../../../images/g7.png';
import r8 from '../../../images/g8.png';
import r9 from '../../../images/g9.png';
import r10 from '../../../images/g10.png';
import r11 from '../../../images/g11.png';
import r12 from '../../../images/g12.png';
import r13 from '../../../images/g13.png';
import r14 from '../../../images/g14.png';
import r15 from '../../../images/g15.png';
import r16 from '../../../images/g16.png';
import r17 from '../../../images/g17.png';
import r18 from '../../../images/g18.png';
import r19 from '../../../images/g19.png';
import r20 from '../../../images/g20.png';
import r21 from '../../../images/g21.png';
import r22 from '../../../images/g21.png';
import r23 from '../../../images/g22.png';
import r24 from '../../../images/g23.png';
import r25 from '../../../images/g24.png';
import r26 from '../../../images/beer.png';
import r27 from '../../../images/g25.png';
import r29 from '../../../images/beer.png';
import r30 from '../../../images/beer.png';
import web1 from '../../../images/web-1.png'
import web2 from '../../../images/web-2.png'
import web3 from '../../../images/web-3.png'
import web4 from '../../../images/web-4.png'
import web5 from '../../../images/web-5.png'
import web6 from '../../../images/web-6.png'
import web7 from '../../../images/web-7.png'
import web8 from '../../../images/web-8.png'
import per1 from '../../../images/per-1.png'
import per2 from '../../../images/per-2.png'
import per3 from '../../../images/per-3.png'
import per4 from '../../../images/per-4.png'
import per5 from '../../../images/per-5.png'
import perL1 from '../../../images/per-l1.png'
import perL2 from '../../../images/per-l2.png'
import perL3 from '../../../images/per-l3.png'
import perL4 from '../../../images/per-l4.png'
import perL5 from '../../../images/per-l5.png'
import ev1 from '../../../images/ev-1.png'
import ev2 from '../../../images/ev-2.png'
import beer from '../../../images/beer.png'
import bg2 from '../../../images/bg-text2.svg'
import Footere from "../../Page1/Footer/Footer";
import pv1 from '../../../images/pv1.png'
import pv2 from '../../../images/pv2.png'
import pv3 from '../../../images/pv3.png'
import pv4 from '../../../images/pv4.png'
import pv5 from '../../../images/pv5.png'
import pv6 from '../../../images/pv6.png'
import pv7 from '../../../images/pv7.png'
import pv8 from '../../../images/pv8.png'
import pv9 from '../../../images/pv9.png'
import texvid from '../../../vedios/tex.mp4'
import mahvid from '../../../vedios/maha.mp4'







const slides = [
  {
    key: 1,
    content: (
      <div className="gal-container-main">
        <div className="container-fluid gal-container" id="main-content">
          <div className="row gal-row">
          
          <div className='bg2-cont' >
            <img className='bg-txt2' src={bg2} alt="" />
          </div>
            <div className="column gal-column">
              <img src={r1} data-aos="fade-right" data-aos-duration="2000" alt="r4" />
              <img src={r4} data-aos="fade-right" data-aos-duration="2000" alt="r4" />
              <img src={r7} data-aos="fade-right" data-aos-duration="2000" alt="r7" />
              <img src={r10} data-aos="fade-right" data-aos-duration="2000" alt="r2" />
              <img src={r13} data-aos="fade-right" data-aos-duration="2000" alt="r2" />
              <img src={r16} data-aos="fade-right" data-aos-duration="2000" alt="pexels-2" />
              <img src={r19} data-aos="fade-right" data-aos-duration="2000" alt="pexels-2" />
              <img src={r22} data-aos="fade-right" data-aos-duration="2000" alt="pexels-2" />
              <img src={r24} data-aos="fade-right" data-aos-duration="2000" alt="pexels-2" />

            </div>
            <div className="column gal-column">
              <img src={r2} data-aos="fade-up" data-aos-duration="2000" alt="r1" />
              <img src={r5} data-aos="fade-up" data-aos-duration="2000" alt="r5" />
              <img src={r8} data-aos="fade-up" data-aos-duration="2000" alt="r8" />
              <img src={r11} data-aos="fade-up" data-aos-duration="2000" alt="pexels-3" />
              <img src={r14} data-aos="fade-up" data-aos-duration="2000" alt="pexels-3" />
              <img src={r17} data-aos="fade-up" data-aos-duration="2000" alt="pexels-3" />
              <img src={r20} data-aos="fade-up" data-aos-duration="2000" alt="pexels-3" />
              <img src={r23} data-aos="fade-up" data-aos-duration="2000" alt="pexels-3" />
              <img src={r25} data-aos="fade-right" data-aos-duration="2000" alt="pexels-2" />
              <img src={r29} data-aos="fade-left" data-aos-duration="2000" alt="pexels-6" />
            </div>
            <div className="column gal-column">
              <img src={r3} data-aos="fade-left" data-aos-duration="2000" alt="r3" />
              <img src={r6} data-aos="fade-left" data-aos-duration="2000" alt="r6" />
              <img src={r9} data-aos="fade-left" data-aos-duration="2000" alt="pexels-4" />
              <img src={r12} data-aos="fade-left" data-aos-duration="2000" alt="pexels-5" />
              <img src={r15} data-aos="fade-left" data-aos-duration="2000" alt="pexels-6" />
              <img src={r18} data-aos="fade-left" data-aos-duration="2000" alt="pexels-6" />
              <img src={r21} data-aos="fade-left" data-aos-duration="2000" alt="pexels-6" />
              <img src={r22} data-aos="fade-left" data-aos-duration="2000" alt="pexels-6" />
              <img src={r27} data-aos="fade-left" data-aos-duration="2000" alt="pexels-6" />

            </div>

          </div>

          
          <Footere />

        </div>
        
      </div>
    )
  },
  {
    key: 2,
    content: (
      <div className="key-2">
        <div className=" service-container2">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web1} />
            </div>
            <div className="col-12 osho-text">
              <h4 className="web-h">Osho Body Body Builders</h4>
              <p className="web-p">Osho Body Builders, a leader in custom commercial vehicle bodies, partnered with us to develop a dynamic website using React. The platform highlights their expertise and features a robust CMS for streamlined content management.</p>
            </div>

          </div>
        </div>

        <div className=" service-container3">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web2} />
            </div>
            <div className="col-12 mr-text">
              <h4 className="web-h">M R Distribution Services</h4>
              <p className="web-p">MR Distributors, based in RS Puram, trusted us to create a digital platform that reflects their commitment to providing diverse investment opportunities. Through React development, we built a user-centric website that simplifies the investment journey. </p>
            </div>

          </div>
        </div>

        <div className=" service-container4">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web3} />
            </div>
            <div className="col-12 osho-text">
              <h4 className="web-h">Jat Techno</h4>
              <p className="web-p">JAT Techno Spintex Mill, a textile manufacturing leader, required a strong online presence. We built a WordPress website equipped with a CMS to effectively showcase their expertise in transforming raw materials into high-quality textile products.</p>
            </div>

          </div>
        </div>

        <div className=" service-container5">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web4} />
            </div>
            <div className="col-12 mr-text">
              <h4 className="web-h">RR Thoranam Mahal</h4>
              <p className="web-p">RR Thoranam Mahal, a Coimbatore-based premier wedding venue, required a digital platform that would captivate potential clients. We delivered a seamless React-powered website that lets potential clients easily explore options for unforgettable celebrations</p>
            </div>

          </div>
        </div>

        <div className=" service-container6">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web5} />
            </div>
            <div className="col-12 osho-text">
              <h4 className="web-h">Gowtham Architect</h4>
              <p className="web-p">Gowtham Architects, a top Coimbatore firm with a 40-years of legacy. We partnered with them to build a WordPress website enhanced with GSAP animations, showcasing their impressive portfolio and providing a dynamic user experience.</p>
            </div>

          </div>
        </div>


        <div className=" service-container7">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web6} />
            </div>
            <div className="col-12 mr-text">
              <h4 className="web-h">Bank Vallet</h4>
              <p className="web-p">Bankvallet, a fintech pioneer, simplifies loans by assessing eligibility and connecting customers with lenders. We created a WordPress website that aligns with their mission, providing a reliable platform to optimize loan approvals and enhance customer satisfaction.</p>
            </div>

          </div>
        </div>

        <div className=" service-container8">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web7} />
            </div>
            <div className="col-12 osho-text pb-5">
              <h4 className="web-h">Sri Muruga Vilas Sweets</h4>
              <p className="web-p">Sri Muruga Vilas is renowned for its delectable range of over 12 traditional Indian sweets and savories. We created a WordPress website that showcases their rich heritage and commitment to quality, inviting customers to indulge in their sweet delights.</p>
            </div>

          </div>
        </div>

        <div className=" service-container7">
          <div className="row web-sec">
            <div className="col-12">
              <img className="web-img" src={web8} />
            </div>
            <div className="col-12 mr-text">
              <h4 className="web-h">Gears and Piston</h4>
              <p className="web-p">Gears and Piston offers top-notch bike servicing, from water and foam washes to comprehensive tune-ups. Our React-powered website provides a seamless user experience, making it easy to book their services.
              </p>
            </div>

          </div>
        </div>
        <Footere />

      </div>


    )
  },
  {
    key: 3,
    content: (
      <div className="key-3">
        <div className="service-container9">
          <div className="row pay-per-main">
            <div className="col-12 col-sm-6 pay-per-img-head">
              <img className="pay-per-img" src={per1} />
            </div>
            <div className="col-12 col-sm-6 pay-text-col">
              <img className="pay-per-logo" src={perL1} />
              <h3 className="pay-per-head">Engagement Ad </h3>
              <p className="pay-per-para">Swasthik Architects, a leading architectural firm, aimed to increase qualified leads. Our PPC campaign focused on generating high-quality leads by targeting potential clients actively seeking architectural services.</p>
              <div className="pay-sub">
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">30,000+</h3>
                  <h6 className="pay-sub-p">Reaches</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">45,000+</h3>
                  <h6 className="pay-sub-p">Impressions</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">30+</h3>
                  <h6 className="pay-sub-p"> Results</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="row pay-per-main pt-5">
            <div className="col-0 col-sm-1"></div>
            <div className="col-12 col-sm-5 order-2  order-sm-1 pay-text-col">
              <img className="pay-per-logo" src={perL2} />
              <h3 className="pay-per-head">Traffic ad </h3>
              <p className="pay-per-para">On My Body by Shreya, a premium fashion brand, aimed to increase online visibility and drive traffic to their website. Our campaign delivered impressive results, using captivating visuals and strategic keywords to attract fashion-forward shoppers </p>
              <div className="pay-sub">
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">80,000</h3>
                  <h6 className="pay-sub-p">Reaches</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">95,000</h3>
                  <h6 className="pay-sub-p">Impressions</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">1000+</h3>
                  <h6 className="pay-sub-p"> Results</h6>
                </div>
              </div>
            </div>
            <div className="col-12 col-sm-6 order-1  order-sm-2 pay-per-img-head2">
              <img className="pay-per-img2" src={per2} />
            </div>
          </div>


          <div className="row pay-per-main pt-5">
            <div className="col-12 col-sm-6 pay-per-img-head">
              <img className="pay-per-img" src={per3} />
            </div>
            <div className="col-12 col-sm-6 pay-text-col">
              <img className="pay-per-logo" src={perL3} />
              <h3 className="pay-per-head">Engagement Ad </h3>
              <p className="pay-per-para">Reva Steel Doors and Windows sought to build stronger relationships with potential customers in a short period. Our engagement-focused campaign used captivating visuals and interactive elements to spark interest, drive conversations, and boost brand loyalty.</p>
              <div className="pay-sub">
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">2000+ </h3>
                  <h6 className="pay-sub-p">Reaches</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">3000+</h3>
                  <h6 className="pay-sub-p">Impressions</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">30+</h3>
                  <h6 className="pay-sub-p"> Results</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="row pay-per-main pt-5">
          <div className="col-0 col-sm-1"></div>
            <div className="col-12 col-sm-5  order-2  order-sm-1 pay-text-col">
              <img className="pay-per-logo" src={perL4} />
              <h3 className="pay-per-head">Lead ad
              </h3>
              <p className="pay-per-para">Zyme Restaurant aimed to increase foot traffic and drive in-store sales. Our lead generation campaign focused on enticing potential customers with irresistible offers and highlighting the restaurant's unique dining experience.</p>
              <div className="pay-sub">
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head"> 25,000</h3>
                  <h6 className="pay-sub-p">Reaches</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head"> 60,000</h3>
                  <h6 className="pay-sub-p">Impressions</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">165
                  </h3>
                  <h6 className="pay-sub-p"> Results</h6>
                </div>
              </div>
            </div>
            <div className="col-12 col-sm-6  order-1  order-sm-2  pay-per-img-head2">
              <img className="pay-per-img2" src={per4} />
            </div>
          </div>

          <div className="row pay-per-main pt-5 pay-per-bot-pading">
            <div className='bg2-cont' >
            <img className='bg-txt2' src={bg2} alt="" />
          </div>
            <div className="col-12 col-sm-6 pay-per-img-head">
              <img className="pay-per-img" src={per5} />
            </div>
            <div className="col-12 col-sm-6 pay-text-col">
              <img className="pay-per-logo" src={perL5} />
              <h3 className="pay-per-head">Engagement Ad </h3>
              <p className="pay-per-para">Kanavu Koodam Constructions aimed to enhance brand visibility and connect with potential clients. Our campaign showcased their expertise in building dream homes with striking visuals, compelling narratives, and interactive elements that resonated with the audience. </p>
              <div className="pay-sub">
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">3,000</h3>
                  <h6 className="pay-sub-p">Reaches</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head"> 6,000</h3>
                  <h6 className="pay-sub-p">Impressions</h6>
                </div>
                <div className="pay-sub-box">
                  <h3 className="pay-sub-head">30+</h3>
                  <h6 className="pay-sub-p"> Results</h6>
                </div>
              </div>
            </div>
          </div>

        </div>
        <Footere />
      </div>
    )
  },
  {
    key: 4,
    content: (
      <div className="key-4">
        <div className="row ev-contain">
          <div className="col-12 ev-text-head">
            <h3 >Weddings</h3>
            <p>Your wedding day is a once-in-a-lifetime event. Let us create a celebration that reflects your love story.</p>
          </div>
          <div className="col-12">
            <div className="row">
              <div className="col-8">
                <img className="ev1" src={ev1} />
              </div>
              <div className="col-4">
                <img className="ev2" src={ev2} />
              </div>
            </div>
          </div>
        </div>

        <div className="row ev-contain ev-top">
          <div className="col-12 ev-text-head">
            <h3 >Corporate events</h3>
            <p> Our corporate events are designed to impress and engage. Let us handle the details while you focus on your business.
            </p>
          </div>
          <div className="col-12">
            <div className="row">
              <div className="col-8">
                <img className="ev1" src={ev1} />
              </div>
              <div className="col-4">
                <img className="ev2" src={ev2} />
              </div>
            </div>
          </div>
        </div>

        <div className="row ev-contain ev-top">
          <div className="col-12 ev-text-head">
            <h3 >Reception</h3>
            <p>Our expert planning ensures your reception is unforgettable. We craft beautiful settings and seamless transitions that impress your guests.</p>
          </div>
          <div className="col-12">
            <div className="row">
              <div className="col-8">
                <img className="ev1" src={ev1} />
              </div>
              <div className="col-4">
                <img className="ev2" src={ev2} />
              </div>
            </div>
          </div>
        </div>

        <div className="row ev-contain ev-top ev-bottom">
        <div className='bg2-cont' >
            <img className='bg-txt2' src={bg2} alt="" />
          </div>
          <div className="col-12 ev-text-head">
            <h3 >Birthday Parties</h3>
            <p>Make every birthday a memorable one. Our creative team transforms ordinary celebrations into extraordinary experiences.
            </p>
          </div>
          <div className="col-12">
            <div className="row">
              <div className="col-8">
                <img className="ev1" src={ev1} />
              </div>
              <div className="col-4">
                <img className="ev2" src={ev2} />
              </div>
            </div>
          </div>
        </div>
        <Footere />

      </div>
    )
  },
  {
    key: 5,
    content: (
      <div className="key-5">
        <div className="row">

          <div className="col-12">

            <div className="container-fluid gal-containers" id="main-content">
              <div>
                <div className="pv-head pv-gal-row"><h4>Photography</h4>
                  <p>Our portfolio captures life's essence through stunning portraits, breathtaking landscapes, unforgettable moments, and captivating product imagery.</p></div>
                <div className="row gal-row">
                  <div className="column gal-column">
                    <img src={pv1} data-aos="fade-right" data-aos-duration="2000" alt="r4" />
                    <img src={pv6} data-aos="fade-right" data-aos-duration="2000" alt="r4" />
                    <img src={pv5} data-aos="fade-right" data-aos-duration="2000" alt="r7" />
                    



                  </div>
                  <div className="column gal-column">
                    <img src={pv3} data-aos="fade-up" data-aos-duration="2000" alt="r1" />
                    <img src={pv2} data-aos="fade-up" data-aos-duration="2000" alt="r5" />
                    <img src={pv7} data-aos="fade-up" data-aos-duration="2000" alt="r8" />
                    


                  </div>
                  <div className="column gal-column">
                  <img src={pv3} data-aos="fade-right" data-aos-duration="2000" alt="r2" />
                  <img src={pv8} data-aos="fade-up" data-aos-duration="2000" alt="pexels-3" />
                  <img src={pv1} data-aos="fade-left" data-aos-duration="2000" alt="pexels-4" />
                  <img src={pv9} data-aos="fade-left" data-aos-duration="2000" alt="pexels-4" />
                    



                  </div>
                </div>

                <div className="pv-head gal-row pb-1"><h4>Vediography</h4>
                  <p> Our videos tell captivating stories, from dynamic event coverage to cinematic narratives. Let us transport you with every frame.
                  </p></div>
              </div>
              <div className="row gal-row">
                <div className="col-12 col-sm-6 pv-beer mt-2">
                  <video className="port-vedio" controls={true} src={texvid}/>
                </div>
                <div className="col-12 col-sm-6 pv-beer mt-2">
                <video className="port-vedio" controls={true}  src={mahvid}/>
                </div>
              </div>
              <Footere/>
            </div>
            
          </div>

        </div>

        

      </div>
    )
  }
];

const GradientStages = [0, 25, 50, 75, 100];

export default class HorizontalSlider extends Component {
  state = {
    goToSlide: 0,
    offsetRadius: 2,
    showNavigation: true,
    config: config.gentle,
    sliderValue: GradientStages[0]
  };

  handleSliderChange = (newValue) => {
    const index = GradientStages.indexOf(newValue);
    this.setState({ sliderValue: newValue, goToSlide: index });
  };

  handleSlideChange = (newIndex) => {
    const newValue = GradientStages[newIndex];
    this.setState({ sliderValue: newValue, goToSlide: newIndex });
  };

  render() {
    return (
      <div className="slide-creative-container">
        <div className="carousel-main-container">

          <HorizontalCarousel
            slides={slides}
            offsetRadius={this.state.offsetRadius}
            showNavigation={this.state.showNavigation}
            animationConfig={this.state.config}
            goToSlide={this.state.goToSlide}
            onSlideChange={this.handleSlideChange} />

        </div>
        <div className="Horizontal-scrollbar-container">
          <SliderLine
            currentValue={this.state.sliderValue}
            onSliderChange={this.handleSliderChange} />
        </div>
      </div>
    );
  }
}
